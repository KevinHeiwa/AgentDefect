package io.joern.dataflowengineoss.passes

package object reachingdef {
  type Definition = Int
}
