package io.joern.javasrc2cpg.jartypereader.testcode.simplenongeneric;

public class Test {
    public int add(int x, int y) {
        return x + y;
    }
}
