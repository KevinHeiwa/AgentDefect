package io.joern.javasrc2cpg.jartypereader.testcode.nongenericinterface;

interface Foo {}

public class Test implements Foo { }
